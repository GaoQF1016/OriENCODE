import importlib.util
from pathlib import Path

try:
    import git
    _git_available = True
except ImportError:  # can cause import errors, not because of package but because of git
    _git_available = False

import oriencode
def oriencode_state() -> str:
    """Get version tag of oriencode. If in repo this will get you the output of git describe.

    Returns git describe, oriencode version or oriencode version with invalid appended.
    """

    p = Path(importlib.util.find_spec('oriencode').origin).parents[1]

    if _git_available:
        try:
            r = git.Repo(p)
            return r.git.describe(dirty=True)

        except git.exc.InvalidGitRepositoryError:  # not a repo but an installed package
            return oriencode.__version__

        except git.exc.GitCommandError:
            return "vINVALID-recent-" + oriencode.__version__
    else:
        return "vINVALID-recent-" + oriencode.__version__


if __name__ == '__main__':
    v = oriencode_state()
    print(f"oriencode version: {v}")
