import pytest
from pathlib import Path

import oriencode.utils.param_io

oriencode_root = Path(__file__).parent.parent
dummy_path = Path('a_dummy_path.txt')


@pytest.mark.parametrize("root", [oriencode_root, str(oriencode_root)])
@pytest.mark.parametrize("path", [dummy_path, str(dummy_path)])
def test_add_root_relative(root, path):
    assert oriencode.utils.param_io.add_root_relative(path, root) == oriencode_root / dummy_path
