# Tests the importability of oriencode, i.e. the most basic test.


def test_import_oriencode():
    import oriencode
def test_import_oriencode_utils():
    import oriencode.utils
