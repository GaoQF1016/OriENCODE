import torch
import torch.nn as nn
from typing import Sequence


class PatchEmbeddingBlock(nn.Module):
    def __init__(self, in_channels: int, patch_size: Sequence[int], hidden_size: int):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_channels, hidden_size, kernel_size=patch_size, stride=patch_size)
    
    def forward(self, x):
        x = self.proj(x)  # Shape: (batch_size, hidden_size, new_height, new_width)
        
        # 计算每个维度的 patch 数量
        num_patches = (x.size(2) * x.size(3))  # new_height * new_width
        
        # 将特征展平为 (batch_size, num_patches, hidden_size)
        x = x.view(x.size(0), -1, x.size(1))  # Flatten to (batch_size, num_patches, hidden_size)
        return x.permute(0, 2, 1)  # Shape: (batch_size, hidden_size, num_patches)


class PositionalEncoding(nn.Module):
    def __init__(self, hidden_size: int, max_len: int = 5000):
        super().__init__()
        self.encoding = torch.zeros(max_len, hidden_size)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, hidden_size, 2).float() * -(torch.log(torch.tensor(10000.0)) / hidden_size))
        self.encoding[:, 0::2] = torch.sin(position * div_term)
        self.encoding[:, 1::2] = torch.cos(position * div_term)
        self.encoding = self.encoding.unsqueeze(0)  # Shape: (1, max_len, hidden_size)

    def forward(self, x):
        return x + self.encoding[:, :x.size(1), :].expand(x.size(0), -1, -1)


class TransformerBlock(nn.Module):
    def __init__(self, hidden_size: int, mlp_dim: int, num_heads: int, dropout_rate: float):
        super().__init__()
        self.attention = nn.MultiheadAttention(hidden_size, num_heads)
        self.norm1 = nn.LayerNorm(hidden_size)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, mlp_dim),
            nn.ReLU(),
            nn.Linear(mlp_dim, hidden_size),
        )
        self.dropout1 = nn.Dropout(dropout_rate)
        self.dropout2 = nn.Dropout(dropout_rate)

    def forward(self, x):
        attn_output, _ = self.attention(x, x, x)
        x = self.norm1(x + self.dropout1(attn_output))
        mlp_output = self.mlp(x)
        x = self.norm2(x + self.dropout2(mlp_output))
        return x


class ViT(nn.Module):
    def __init__(
        self,
        in_channels: int,
        patch_size: Sequence[int],
        hidden_size: int = 768,
        mlp_dim: int = 3072,
        num_layers: int = 12,
        num_heads: int = 12,
        dropout_rate: float = 0.0,
        classification: bool = False,
        num_classes: int = 2,
        max_len: int = 196,  # 这里设置一个最大长度，假设每张图有9696个patch，256个长宽比结构
    ) -> None:
        super().__init__()

        self.patch_embedding = PatchEmbeddingBlock(in_channels, patch_size, hidden_size)
        self.positional_encoding = PositionalEncoding(hidden_size, max_len)
        self.blocks = nn.ModuleList([
            TransformerBlock(hidden_size, mlp_dim, num_heads, dropout_rate) for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(hidden_size)
        
        if classification:
            self.cls_token = nn.Parameter(torch.zeros(1, 1, hidden_size))
            self.classification_head = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        x = self.patch_embedding(x)
        
        if hasattr(self, "cls_token"):
            cls_token = self.cls_token.expand(x.size(0), -1, -1)  # Expand to (batch_size, 1, hidden_size)
            x = torch.cat((cls_token, x), dim=1)  # Concatenate class token to the patches
        
        x = self.positional_encoding(x)  # 添加位置编码

        hidden_states_out = []
        for blk in self.blocks:
            x = blk(x)
            hidden_states_out.append(x)

        x = self.norm(x)
        
        if hasattr(self, "classification_head"):
            return self.classification_head(x[:, 0]), hidden_states_out  # Use the class token for classification
        return x, hidden_states_out